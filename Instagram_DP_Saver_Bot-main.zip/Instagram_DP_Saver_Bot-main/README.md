## Instagram DP Saver Bot

### A telegram bot to get a anyone's Instagram DP

## Dependencies

- instaloader\
  `pip3 install instaloader`
- python telegram wrapper\
  `pip3 install python-telegram-bot`

## Available commands

- `/start` - Starts the bot.

- `/help` - Help(Yeses,Its relay useful).

- Or just send anyone's Instagram username to get their DP.

## You can deploy the bot yourself here(The easy way)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/anishgowda21/Instagram_DP_Saver_Bot)

## Watch the video here

<a href = "https://youtu.be/lLRP9j_VizM"><img src="https://raw.githubusercontent.com/anishgowda21/SVG_for_README/main/youtube-minimal-icon-1.svg" width="100px"></a>

## Visit my bot [Instagram DP Saver Bot](https://telegram.dog/insta_dp_saver_bot)
